const player = document.getElementById('player');
const enemy = document.getElementById('enemy');
const playerHealthBar = document.getElementById('player-health');
const enemyHealthBar = document.getElementById('enemy-health');
const shootSound = document.getElementById('shoot-sound');
const winSound = document.getElementById('win-sound');
const loseSound = document.getElementById('lose-sound');
const scoreEl = document.getElementById('score');

let playerHP = 100;
let enemyHP = 100;
let isCrouching = false;
let score = 0;

player.style.left = '50px';
enemy.style.left = '700px';

document.addEventListener('keydown', (e) => {
  let current = player.offsetLeft;
  const step = 20;
  switch (e.key) {
    case 'ArrowRight':
      player.style.left = `${Math.min(current + step, 750)}px`;
      setPlayerSprite('walk');
      break;
    case 'ArrowLeft':
      player.style.left = `${Math.max(current - step, 0)}px`;
      setPlayerSprite('walk');
      break;
    case 'Backspace':
      shootBullet();
      break;
    case 'c':
    case 'C':
      crouch(true);
      break;
  }
});
document.addEventListener('keyup', (e) => {
  if (e.key === 'c' || e.key === 'C') {
    crouch(false);
  } else {
    setPlayerSprite('idle');
  }
});
function setPlayerSprite(state) {
  if (state === 'walk') {
    player.src = 'assets/player-walk.gif';
  } else if (state === 'crouch') {
    player.src = 'assets/player-crouch.png';
  } else if (state === 'shoot') {
    player.src = 'assets/player-shoot.gif';
  } else {
    player.src = 'assets/player-walk.gif';
  }
}
function crouch(shouldCrouch) {
  isCrouching = shouldCrouch;
  setPlayerSprite(shouldCrouch ? 'crouch' : 'idle');
}
function shootBullet() {
  shootSound.play();
  setPlayerSprite('shoot');
  const bullet = document.createElement('div');
  bullet.classList.add('bullet');
  bullet.style.left = `${player.offsetLeft + 50}px`;
  bullet.style.top = '200px';
  document.getElementById('game').appendChild(bullet);
  const interval = setInterval(() => {
    bullet.style.left = `${bullet.offsetLeft + 15}px`;
    if (bullet.offsetLeft > 800) {
      bullet.remove();
      clearInterval(interval);
    }
    if (bullet.offsetLeft >= enemy.offsetLeft && bullet.offsetLeft <= enemy.offsetLeft + 60) {
      enemyHP -= 10;
      enemyHealthBar.style.width = `${enemyHP}%`;
      bullet.remove();
      clearInterval(interval);
      if (enemyHP <= 0) {
        winSound.play();
        alert('You Win!');
        score += 1;
        scoreEl.textContent = score;
        resetGame();
      }
    }
  }, 30);
}
function enemyAI() {
  const p = player.offsetLeft;
  const e = enemy.offsetLeft;
  const step = 10;
  if (Math.abs(p - e) > 60) {
    enemy.style.left = p > e
      ? `${Math.min(e + step, 750)}px`
      : `${Math.max(e - step, 0)}px`;
  } else {
    if (!isCrouching) {
      playerHP -= 5;
      playerHealthBar.style.width = `${playerHP}%`;
      if (playerHP <= 0) {
        loseSound.play();
        alert("You Lose!");
        score = 0;
        scoreEl.textContent = score;
        resetGame();
      }
    }
  }
}
setInterval(enemyAI, 500);
function resetGame() {
  playerHP = 100;
  enemyHP = 100;
  playerHealthBar.style.width = '100%';
  enemyHealthBar.style.width = '100%';
  player.style.left = '50px';
  enemy.style.left = '700px';
}
